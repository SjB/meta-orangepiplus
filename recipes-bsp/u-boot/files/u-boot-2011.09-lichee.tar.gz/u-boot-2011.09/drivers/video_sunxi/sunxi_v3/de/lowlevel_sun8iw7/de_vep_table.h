#ifndef __DE_VEP_TAB__
#define __DE_VEP_TAB__

extern int y2r[192];
extern int r2y[128];
extern int y2y[64];
extern int r2r[32];
extern int bypass_csc[12];
extern unsigned int sin_cos[128];
extern int fcc_range_gain[6];

#endif
