/*
const __disp_vga_t disp_vga_h1024_v768 = 
{
	//__u32	pixel_clk;
	65000000,
	//__u16	hor_pixels;
	1024,
	//__u16	ver_pixels;
	768,
	//__u16	hor_total_time;
	1344,
	//__u16	hor_front_porch;
	24,
	//__u16	hor_sync_time;	
	136,
	//__u16	hor_back_porch;
	160,
	//__u16	ver_total_time;
	806,
	//__u16	ver_front_porch;
	3,
	//__u16	ver_sync_time;
	6,
	//__u16	ver_back_porch;
	9,
	//__bool	hor_sync_polarity;
	0,
	//__bool	ver_sync_polarity;
	0,	
};
*/
